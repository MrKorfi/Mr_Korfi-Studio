# Mr_Korfi Studio

Ein responsiver Prototyp für eine KI-Unternehmenszentrale.

## Start
Öffne `index.html` im Browser oder veröffentliche das Repository über Vercel.

## Enthalten
- Dashboard
- Auftragsverwaltung
- KI-Abteilungen
- Projektübersicht
- Demo-Freigabecenter
- Einstellungen
- Kundenanfrage-Demo

## Wichtige Hinweise
Diese Version speichert Daten nur lokal im Browser (`localStorage`). Sie enthält noch keinen echten Login, keine gemeinsame Cloud-Datenbank, keine echte KI-Ausführung und keine tatsächliche öffentliche Kundenübermittlung. Für den Produktivbetrieb müssen Backend, Authentifizierung, Datenbank und KI-API sicher eingerichtet werden.
